
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class addmemory extends JFrame {
	private static final long serialVersionUID = 1L;
	static addmemory frame;
	private JPanel contentPane;
	private JTextField TextField;
	private JTextField TextField_1;
	private JTextField TextField_2;
	

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new addmemory();
					frame.setTitle("Add Memory");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addmemory() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(110, 95, 650, 400);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        TextField = new JTextField();
        TextField.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField.setBounds(290, 125, 326, 40);
        contentPane.add(TextField);
        TextField.setColumns(10);

        TextField_1 = new JTextField();
        TextField_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField_1.setBounds(290, 175, 326, 40);
        contentPane.add(TextField_1);
        TextField_1.setColumns(10);
        
        TextField_2 = new JTextField();
        TextField_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField_2.setBounds(290, 225, 326, 40);
        contentPane.add(TextField_2);
        TextField_2.setColumns(10);
        
        
        
        TextField.setText("");
		TextField_1.setText("");
		TextField_2.setText("");
		
		JLabel lbladdmemorys = new JLabel("Add Memory");
        lbladdmemorys.setFont(new Font("Courier New", Font.BOLD, 36));
        lbladdmemorys.setForeground(Color.BLACK);
        lbladdmemorys.setBounds(275, 27, 350, 40);
        contentPane.add(lbladdmemorys);
        
		JLabel lblmanu = new JLabel("Manufacturer :");
        lblmanu.setFont(new Font("Big Calson", Font.PLAIN, 18));
        lblmanu.setBounds(45, 125, 326, 40);
        contentPane.add(lblmanu);
		
		JLabel lblram = new JLabel("Capof.RAM(gb) :");
        lblram.setFont(new Font("Freestyle Script", Font.PLAIN, 18));
        lblram.setBounds(45, 175, 410, 40);
        contentPane.add(lblram);
        
		JLabel lblhd = new JLabel("Capof.HardD(gb) :");
        lblhd.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblhd.setBounds(45, 225, 470, 40);
        contentPane.add(lblhd);
        
        
        
		JButton btnaddmemorys = new JButton("Submit");
		btnaddmemorys.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String m=TextField.getText();
			
			int ram;
			int  hd;
			
			if((TextField_1.getText()).equals(""))
				ram = 0;
			else
				ram=Integer.parseInt(TextField_1.getText());
			
			if((TextField_2.getText()).equals(""))
				hd = 0;
			else
				hd=Integer.parseInt(TextField_2.getText());
			
			
			
			if(m.equals("") || ram==0 || hd==0) {
				JOptionPane.showMessageDialog(addmemory.this,"Unknown Error !!!\n TextField Cannot be Blank");
			}
			else {
			if(memorydetails.checkmemory(m)) {
				JOptionPane.showMessageDialog(addmemory.this,"Details with Same Manufacture is present already\nInserton Failed !!!");
			}
			else {
			int i=memorydetails.insertmemory(m,ram,hd);
			if(i>0){
				JOptionPane.showMessageDialog(addmemory.this,"Details added successfully!");
			}else{
				JOptionPane.showMessageDialog(addmemory.this,"Unknown Error !!!\nInsertion not completed");
			}
			}
			}
			}
		});
		btnaddmemorys.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnaddmemorys.setBackground(new Color(0,0, 0));
        btnaddmemorys.setBounds(300, 315, 130, 50);
        contentPane.add(btnaddmemorys);

		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e1) {
				memory.main(new String[]{});
				frame.dispose();
			}
			});
		  btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        btnBack.setBackground(new Color(240, 240, 240));
	        btnBack.setBounds(450, 315, 130, 50);
	        contentPane.add(btnBack);
	}

}

