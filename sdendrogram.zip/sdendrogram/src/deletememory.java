import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class deletememory extends JFrame {
	private static final long serialVersionUID = 1L;
	static deletememory frame;
	private JPanel contentPane;
    private JTextField TextField;
    private JLabel manufacturer;
    private JTextField TextField1;
    private JLabel ram;
    private JTextField TextField2;
    private JLabel hd;
    
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new deletememory();
					frame.setTitle("Delete Memory");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public deletememory() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(110, 95, 650, 420);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lbladdchasis = new JLabel("Delete Memory");
        lbladdchasis.setFont(new Font("Courier New", Font.BOLD, 36));
        lbladdchasis.setForeground(Color.BLACK);
        lbladdchasis.setBounds(275, 27, 350, 40);
        contentPane.add(lbladdchasis);

        TextField = new JTextField();
        TextField.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField.setBounds(290, 125, 326, 40);
        contentPane.add(TextField);
        TextField.setColumns(10);

        TextField1 = new JTextField();
        TextField1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField1.setBounds(290, 175, 350, 40);
        TextField1.setEditable(false);
        contentPane.add(TextField1);
        TextField.setColumns(20);
        
        TextField2 = new JTextField();
        TextField2.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField2.setBounds(290, 225, 350, 40);
        contentPane.add(TextField2);
        TextField2.setEditable(false);
        TextField.setColumns(20);
        
       
        
        TextField.setText("");
		TextField1.setText("");
		TextField2.setText("");

	    manufacturer = new JLabel("Manufacturer :");
        manufacturer.setFont(new Font("Tahoma", Font.PLAIN, 18));
        manufacturer.setBounds(45, 125, 326, 40);
        contentPane.add(manufacturer);
        
        ram = new JLabel("Capof.RAM(gb) :");
        ram.setFont(new Font("Tahoma", Font.PLAIN, 18));
        ram.setBounds(45, 175, 326, 40);
        contentPane.add(ram);
        
        hd = new JLabel("Capof.HardD(gb) :");
        hd.setFont(new Font("Tahoma", Font.PLAIN, 18));
        hd.setBounds(45, 225, 326, 40);
        contentPane.add(hd);
        
       

		 Connection con = mysqlconn.getConnection();
		 
		 JButton btnBack = new JButton("Back");
	        btnBack.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	frame.dispose();
	            	memory.main(new String[]{});
	            }});
	        btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        btnBack.setBackground(new Color(240, 240, 240));
	        btnBack.setBounds(450, 315, 130, 50);
	        contentPane.add(btnBack);
        JButton btnDelete = new JButton("Delete");
        btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String manufacturer=TextField.getText();
				if(manufacturer==null||manufacturer.trim().equals("")){
					JOptionPane.showMessageDialog(deletememory.this,"Manufacturer can't be blank");
				}else{
					
					int i=memorydetails.deletememory(manufacturer);
					if(i>0){
						JOptionPane.showMessageDialog(deletememory.this,"Memory Details deleted successfully!");
						System.out.println("Deleted Chasis of Manufacturer : "+manufacturer);
					}else{
						JOptionPane.showMessageDialog(deletememory.this,"Unable to delete given Manufacturer!");
					}
				}
				TextField.setText("");
				TextField1.setText("");
				TextField2.setText("");

			}
		});
        btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnDelete.setBackground(new Color(240, 240, 240));
        btnDelete.setBounds(300, 315, 130, 50);
        contentPane.add(btnDelete);
        
        TextField.addKeyListener((KeyListener) new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                	String manufacturer = TextField.getText();
                    
                	Connection con = mysqlconn.getConnection();
                	if(memorydetails.checkmemory(manufacturer)) {
                	Statement st;
    				try {
    					PreparedStatement stmt = con.prepareStatement("select * from memory where manufacturer=?");
    					stmt.setString(1,manufacturer);
    					ResultSet rs = stmt.executeQuery();
    					while(rs.next())   
    					{	TextField.setText(rs.getString(1));
    			TextField1.setText(rs.getString(2));
    			TextField2.setText(rs.getString(3));

    			}
    			} catch (SQLException e1) {
    				e1.printStackTrace();
    			}}else {
    				JOptionPane.showMessageDialog(deletememory.this,"Manufacturer is Invalid !!!");
    				TextField.setText("");
    				TextField1.setText("");
    				TextField2.setText("");

    			}

                }}});
        
        
        JButton btnLoad = new JButton("Load");
        btnLoad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	  String manufacturer = TextField.getText();
                 
            	Connection con = mysqlconn.getConnection();
            	if(memorydetails.checkmemory(manufacturer)) {
            	Statement st;
				try {
					PreparedStatement stmt = con.prepareStatement("select * from memory where manufacturer=?");
					stmt.setString(1,manufacturer);
					ResultSet rs = stmt.executeQuery();
					while(rs.next())   
					{	TextField.setText(rs.getString(1));
			TextField1.setText(rs.getString(2));
			TextField2.setText(rs.getString(3));


			}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}}else {
				JOptionPane.showMessageDialog(deletememory.this,"Manufacturer is Invalid !!!");
				TextField.setText("");
				TextField1.setText("");
				TextField2.setText("");

			}

            }});
        btnLoad.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnLoad.setBackground(new Color(240, 240, 240));
        btnLoad.setBounds(150, 315, 130, 50);
        contentPane.add(btnLoad);
        
    }
}
