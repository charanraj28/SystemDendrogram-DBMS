import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class memorydetails {
	public static boolean checkmemory(String manufacturer){
		boolean stat=false;
		try{
			Connection con=mysqlconn.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from memory where manufacturer=?");
			ps.setString(1,manufacturer);
		    ResultSet rs=ps.executeQuery();
			stat=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return stat;
	}
	public static int insertmemory(String manufacturer,int ram,int hd){
		int status=0;
		try{
			Connection con=mysqlconn.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into memory(manufacturer,capof_ram_in_gb,capof_hardd_in_gb) values(?,?,?)");
			ps.setString(1,manufacturer);
			ps.setInt(2,ram);
			ps.setInt(3,hd);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int deletememory(String manufacturer){
		int status=0;
		try{
			Connection con=mysqlconn.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from memory where manufacturer=?");
			ps.setString(1,manufacturer);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
}

