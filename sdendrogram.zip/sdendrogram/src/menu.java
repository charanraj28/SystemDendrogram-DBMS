import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import java.awt.Font;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class menu extends JFrame {
	private static final long serialVersionUID = 1L;
	static menu frame;
	private JPanel contentPane;
	static String idd;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new menu();
					frame.setTitle("System Dendrogram");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
     
	/**
	 * Create the frame.
	 */
	public menu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 450, 433);
		contentPane = new JPanel();
		contentPane.setForeground(Color.GRAY);
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		//JLabel d = new JLabel("System Dendrogram");
		
		JButton btncpuinfo = new JButton("CPU Info");
		btncpuinfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			cpu.main(new String[]{});
			frame.dispose();
			}
		});
		btncpuinfo.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JButton btnchasisinfo = new JButton("Chasis Info");
		btnchasisinfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				chasis.main(new String[]{});
				frame.dispose();
			}
		});
		btnchasisinfo.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JButton btnmemoryinfo = new JButton("Memory Info");
		btnmemoryinfo.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				memory.main(new String[]{});
				frame.dispose();
			}
		});
		btnmemoryinfo.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		JButton btndendro = new JButton("Generate Dendrogram");
		btndendro.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dendrogram.main(new String[]{});
				frame.dispose();
			}
		});
		btndendro.setFont(new Font("Tahoma", Font.PLAIN, 13));
		
		
		
		
		
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
					.addContainerGap(81, Short.MAX_VALUE)
					//.addComponent(dendrogra)
					.addGap(54))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(132)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						
						.addComponent(btnmemoryinfo, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
						.addComponent(btndendro, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)

						.addComponent(btnchasisinfo, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE)
						.addComponent(btncpuinfo, GroupLayout.PREFERRED_SIZE, 191, GroupLayout.PREFERRED_SIZE))
					    
					
					.addContainerGap(101, Short.MAX_VALUE))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					//.addComponent(dendrogra)
					//.addGap(18)
					.addComponent(btncpuinfo, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnchasisinfo, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btndendro, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(btnmemoryinfo, GroupLayout.PREFERRED_SIZE, 37, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					
		));
		contentPane.setLayout(gl_contentPane);
	}

}
