import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class deletechasis extends JFrame {
	private static final long serialVersionUID = 1L;
	static deletechasis frame;
	private JPanel contentPane;
    private JTextField TextField;
    private JLabel manufacturer;
    private JTextField TextField1;
    private JLabel l;
    private JTextField TextField2;
    private JLabel w;
    private JTextField TextField3;
    private JLabel weight;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new deletechasis();
					frame.setTitle("Delete Chasis");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public deletechasis() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(110, 95, 650, 420);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lbladdchasis = new JLabel("Delete Chasis");
        lbladdchasis.setFont(new Font("Courier New", Font.BOLD, 36));
        lbladdchasis.setForeground(Color.BLACK);
        lbladdchasis.setBounds(275, 27, 350, 40);
        contentPane.add(lbladdchasis);

        TextField = new JTextField();
        TextField.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField.setBounds(290, 125, 326, 40);
        contentPane.add(TextField);
        TextField.setColumns(10);

        TextField1 = new JTextField();
        TextField1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField1.setBounds(290, 175, 350, 40);
        TextField1.setEditable(false);
        contentPane.add(TextField1);
        TextField.setColumns(20);
        
        TextField2 = new JTextField();
        TextField2.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField2.setBounds(290, 225, 350, 40);
        contentPane.add(TextField2);
        TextField2.setEditable(false);
        TextField.setColumns(20);
        
        TextField3 = new JTextField();
        TextField3.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField3.setBounds(290, 275, 350, 40);
        contentPane.add(TextField3);
        TextField3.setEditable(false);
        TextField.setColumns(20);
        
        TextField.setText("");
		TextField1.setText("");
		TextField2.setText("");
		TextField3.setText("");

	    manufacturer = new JLabel("Manufacturer :");
        manufacturer.setFont(new Font("Tahoma", Font.PLAIN, 18));
        manufacturer.setBounds(45, 125, 326, 40);
        contentPane.add(manufacturer);
        
        l = new JLabel("Length(cm) :");
        l.setFont(new Font("Tahoma", Font.PLAIN, 18));
        l.setBounds(45, 175, 326, 40);
        contentPane.add(l);
        
        w = new JLabel("Width(cm) :");
        w.setFont(new Font("Tahoma", Font.PLAIN, 18));
        w.setBounds(45, 225, 326, 40);
        contentPane.add(w);
        
        weight = new JLabel("Weight(kg) :");
        weight.setFont(new Font("Tahoma", Font.PLAIN, 18));
        weight.setBounds(45, 275, 326, 40);
        contentPane.add(weight);

		 Connection con = mysqlconn.getConnection();
		 
		 JButton btnBack = new JButton("Back");
	        btnBack.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	frame.dispose();
	            	chasis.main(new String[]{});
	            }});
	        btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        btnBack.setBackground(new Color(240, 240, 240));
	        btnBack.setBounds(450, 315, 130, 50);
	        contentPane.add(btnBack);
        JButton btnDelete = new JButton("Delete");
        btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String manufacturer=TextField.getText();
				if(manufacturer==null||manufacturer.trim().equals("")){
					JOptionPane.showMessageDialog(deletechasis.this,"Manufacturer can't be blank");
				}else{
					
					int i=chasisdetails.deletechasis(manufacturer);
					if(i>0){
						JOptionPane.showMessageDialog(deletechasis.this,"Chasis deleted successfully!");
						System.out.println("Deleted Chasis of Manufacturer : "+manufacturer);
					}else{
						JOptionPane.showMessageDialog(deletechasis.this,"Unable to delete given Manufacturer!");
					}
				}
				TextField.setText("");
				TextField1.setText("");
				TextField2.setText("");
				TextField3.setText("");

			}
		});
        btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnDelete.setBackground(new Color(240, 240, 240));
        btnDelete.setBounds(300, 315, 130, 50);
        contentPane.add(btnDelete);
        
        TextField.addKeyListener((KeyListener) new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
                	String manufacturer = TextField.getText();
                    
                	Connection con = mysqlconn.getConnection();
                	if(chasisdetails.checkchasis(manufacturer)) {
                	Statement st;
    				try {
    					PreparedStatement stmt = con.prepareStatement("select * from chasis where manufacturer=?");
    					stmt.setString(1,manufacturer);
    					ResultSet rs = stmt.executeQuery();
    					while(rs.next())   
    					{	TextField.setText(rs.getString(1));
    			TextField1.setText(rs.getString(2));
    			TextField2.setText(rs.getString(3));
    			TextField3.setText(rs.getString(4));

    			}
    			} catch (SQLException e1) {
    				e1.printStackTrace();
    			}}else {
    				JOptionPane.showMessageDialog(deletechasis.this,"Manufacturer is Invalid !!!");
    				TextField.setText("");
    				TextField1.setText("");
    				TextField2.setText("");
    				TextField3.setText("");

    			}

                }}});
        
        
        JButton btnLoad = new JButton("Load");
        btnLoad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	  String manufacturer = TextField.getText();
                 
            	Connection con = mysqlconn.getConnection();
            	if(chasisdetails.checkchasis(manufacturer)) {
            	Statement st;
				try {
					PreparedStatement stmt = con.prepareStatement("select * from chasis where manufacturer=?");
					stmt.setString(1,manufacturer);
					ResultSet rs = stmt.executeQuery();
					while(rs.next())   
					{	TextField.setText(rs.getString(1));
			TextField1.setText(rs.getString(2));
			TextField2.setText(rs.getString(3));
			TextField3.setText(rs.getString(4));


			}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}}else {
				JOptionPane.showMessageDialog(deletechasis.this,"Manufacturer is Invalid !!!");
				TextField.setText("");
				TextField1.setText("");
				TextField2.setText("");
				TextField3.setText("");

			}

            }});
        btnLoad.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnLoad.setBackground(new Color(240, 240, 240));
        btnLoad.setBounds(150, 315, 130, 50);
        contentPane.add(btnLoad);
        
    }
}
