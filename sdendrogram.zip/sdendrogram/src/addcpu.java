
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;

import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class addcpu extends JFrame {
	private static final long serialVersionUID = 1L;
	static addcpu frame;
	private JPanel contentPane;
	private JTextField TextField;
	private JTextField TextField_1;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new addcpu();
					frame.setTitle("CPU Info.");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addcpu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(110, 95, 650, 400);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        TextField = new JTextField();
        TextField.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField.setBounds(290, 125, 326, 40);
        contentPane.add(TextField);
        TextField.setColumns(10);

        TextField_1 = new JTextField();
        TextField_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField_1.setBounds(290, 175, 326, 40);
        contentPane.add(TextField_1);
        TextField_1.setColumns(10);
        
        
        
        TextField.setText("");
		TextField_1.setText("");
		
		JLabel lbladdcpus = new JLabel("Add CPU");
        lbladdcpus.setFont(new Font("Courier New", Font.BOLD, 36));
        lbladdcpus.setForeground(Color.BLACK);
        lbladdcpus.setBounds(275, 27, 200, 40);
        contentPane.add(lbladdcpus);
		JLabel lblmanu = new JLabel("Manufacturer :");
        lblmanu.setFont(new Font("Big Calson", Font.PLAIN, 18));
        lblmanu.setBounds(45, 125, 326, 40);
        contentPane.add(lblmanu);
		
		JLabel mid = new JLabel("M-ID :");
        mid.setFont(new Font("Big Calson", Font.PLAIN, 18));
        mid.setBounds(45, 175, 326, 40);
        contentPane.add(mid);
		JButton btnaddcpus = new JButton("Submit");
		btnaddcpus.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String m =TextField.getText();
			int mid;
			if((TextField_1.getText()).equals(""))
				mid = 0;
			else
				mid=Integer.parseInt(TextField_1.getText());
			
			if(m.equals("")|| mid ==0) {
				JOptionPane.showMessageDialog(addcpu.this,"Unknown Error !!!\n TextField Cannot be Blank");
			}
			else {
			if(cpudetails.checkcpu(m)) {
				JOptionPane.showMessageDialog(addcpu.this,"CPU with Same manufacturer is present already\nInserton Failed !!!");
			}
			else {
			int i=cpudetails.insertcpu(m,mid);
			if(i>0){
				JOptionPane.showMessageDialog(addcpu.this,"CPU added successfully!");
			}else{
				JOptionPane.showMessageDialog(addcpu.this,"Unknown Error !!!\nInsertion not completed");
			}
			}
			}
			}
		});
		btnaddcpus.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnaddcpus.setBackground(new Color(240, 240, 240));
        btnaddcpus.setBounds(300, 300, 130, 50);
        contentPane.add(btnaddcpus);

		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e1) {
				cpu.main(new String[]{});
				frame.dispose();
			}
			});
		  btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        btnBack.setBackground(new Color(240, 240, 240));
	        btnBack.setBounds(450, 300, 130, 50);
	        contentPane.add(btnBack);
	}

}


