import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JButton;

import java.awt.Font;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.awt.event.ActionEvent;

public class deletecpu extends JFrame {
	private static final long serialVersionUID = 1L;
	static deletecpu frame;
	private JPanel contentPane;
    private JTextField TextField;
    private JLabel lblmanufacturer;
    private JTextField TextField1;
    private JLabel lblmid;
    

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new deletecpu();
					frame.setTitle("Delete CPU Info.");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public deletecpu() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(110, 95, 650, 420);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);
        JLabel lblAddBooks = new JLabel("Delete CPU");
        lblAddBooks.setFont(new Font("Courier New", Font.BOLD, 36));
        lblAddBooks.setForeground(Color.BLACK);
        lblAddBooks.setBounds(275, 27, 350, 40);
        contentPane.add(lblAddBooks);

        TextField = new JTextField();
        TextField.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField.setBounds(290, 125, 326, 40);
        contentPane.add(TextField);
        TextField.setColumns(10);

        TextField1 = new JTextField();
        TextField1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField1.setBounds(290, 175, 350, 40);
        TextField1.setEditable(false);
        contentPane.add(TextField1);
        TextField.setColumns(20);
        
        
        
        TextField.setText("");
		TextField1.setText("");
		
	    lblmanufacturer = new JLabel("Manufacturer :");
        lblmanufacturer.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblmanufacturer.setBounds(45, 125, 326, 40);
        contentPane.add(lblmanufacturer);
        
        lblmid = new JLabel("M-ID:");
        lblmid.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblmid.setBounds(45, 175, 326, 40);
        contentPane.add(lblmid);
        
       

		 Connection con = mysqlconn.getConnection();
		 
		 JButton btnBack = new JButton("Back");
	        btnBack.addActionListener(new ActionListener() {
	            public void actionPerformed(ActionEvent e) {
	            	frame.dispose();
	            	cpu.main(new String[]{});
	            }});
	        btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        btnBack.setBackground(new Color(240, 240, 240));
	        btnBack.setBounds(450, 300, 130, 50);
	        contentPane.add(btnBack);
        JButton btnDelete = new JButton("Delete");
        btnDelete.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String m=TextField.getText();
				if(m.equals("")){
					JOptionPane.showMessageDialog(deletecpu.this,"Manufacturer can't be blank");
				}else{
					
					int i=cpudetails.deletecpu(m);
					if(i>0){
						JOptionPane.showMessageDialog(deletecpu.this,"CPU deleted successfully!");
						System.out.println("Deleted record of Manufacturer : "+m);
					}else{
						JOptionPane.showMessageDialog(deletecpu.this,"Unable to delete given Manufacturer!");
					}
				}
				TextField.setText("");
				TextField1.setText("");
			}
		});
        btnDelete.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnDelete.setBackground(new Color(240, 240, 240));
        btnDelete.setBounds(300, 300, 130, 50);
        contentPane.add(btnDelete);
        
        TextField.addKeyListener((KeyListener) new KeyAdapter() {
          //  @Override
            public void keyPressed(KeyEvent e) {
                if(e.getKeyCode() == KeyEvent.VK_ENTER){
         
                	Connection con = mysqlconn.getConnection();
                	
                	String m=TextField.getText();
    				if(m.equals("")){
    					JOptionPane.showMessageDialog(deletecpu.this,"Manufacturer can't be blank");
    				}
    				else{
    					
    	
    				if(cpudetails.checkcpu(m)){
                	Statement st;
    				try {
    					PreparedStatement stmt = con.prepareStatement("select * from CPU where manufacturer=?");
    					stmt.setString(1,m);
    					ResultSet rs = stmt.executeQuery();
    					while(rs.next())   
    					{	TextField.setText(rs.getString(1));
    			TextField1.setText(Integer.toString(rs.getInt(2)));
    			//TextField2.setText(rs.getString(3));
    			}
    			} catch (SQLException e1) {
    				e1.printStackTrace();
    			}}else {
    				JOptionPane.showMessageDialog(deletecpu.this,"Manufacturer is Invalid !!!");
    				TextField.setText("");
    				TextField1.setText("");
    			//	TextField2.setText("");
    			}
    				}
                }}});
        
        
        JButton btnLoad = new JButton("Load");
        btnLoad.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
            	  String roll = TextField.getText();
                 
            	Connection con = mysqlconn.getConnection();
            	if(cpudetails.checkcpu(roll)) {
            	Statement st;
				try {
					PreparedStatement stmt = con.prepareStatement("select * from cpu where manufacturer=?");
					stmt.setString(1,roll);
					ResultSet rs = stmt.executeQuery();
					while(rs.next())   
					{	TextField.setText(rs.getString(1));
			TextField1.setText(rs.getString(2));
			
			}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}}else {
				JOptionPane.showMessageDialog(deletecpu.this,"book ID is Invalid !!!");
				TextField.setText("");
				TextField1.setText("");
			
			}

            }});
        btnLoad.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnLoad.setBackground(new Color(240, 240, 240));
        btnLoad.setBounds(150, 300, 130, 50);
        contentPane.add(btnLoad);
        
    }
}

