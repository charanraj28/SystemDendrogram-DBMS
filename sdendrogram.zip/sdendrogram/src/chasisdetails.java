import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class chasisdetails {
	public static boolean checkchasis(String manufacturer){
		boolean stat=false;
		try{
			Connection con=mysqlconn.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from chasis where manufacturer=?");
			ps.setString(1,manufacturer);
		    ResultSet rs=ps.executeQuery();
			stat=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return stat;
	}
	public static int insertchasis(String manufacturer,int l,int w,int weight){
		int status=0;
		try{
			Connection con=mysqlconn.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into chasis(manufacturer,length_in_cm,width_in_cm,weight_in_kg) values(?,?,?,?)");
			ps.setString(1,manufacturer);
			ps.setInt(2,l);
			ps.setInt(3,w);
			ps.setInt(4,weight);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int deletechasis(String manufacturer){
		int status=0;
		try{
			Connection con=mysqlconn.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from chasis where manufacturer=?");
			ps.setString(1,manufacturer);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	
}
