import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class cpudetails {

	public static boolean checkcpu(String manufacturer){
		boolean status=false;
		try{
			Connection con=mysqlconn.getConnection();
			PreparedStatement ps=con.prepareStatement("select * from cpu where manufacturer=?");
			ps.setString(1,manufacturer);
		    ResultSet rs=ps.executeQuery();
			status=rs.next();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int insertcpu(String manufacturer,int mid){
		int status=0;
		try{
			Connection con=mysqlconn.getConnection();
			PreparedStatement ps=con.prepareStatement("insert into cpu(manufacturer,mid) values(?,?)");
			ps.setString(1,manufacturer);
			ps.setInt(2,mid);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
	public static int deletecpu(String manufacturer){
		int status=0;
		try{
			Connection con=mysqlconn.getConnection();
			PreparedStatement ps=con.prepareStatement("delete from cpu where manufacturer=?");
			ps.setString(1,manufacturer);
			status=ps.executeUpdate();
			con.close();
		}catch(Exception e){System.out.println(e);}
		return status;
	}
}