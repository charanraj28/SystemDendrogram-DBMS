
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;

import java.awt.Font;
import java.awt.Color;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class addchasis extends JFrame {
	private static final long serialVersionUID = 1L;
	static addchasis frame;
	private JPanel contentPane;
	private JTextField TextField;
	private JTextField TextField_1;
	private JTextField TextField_2;
	private JTextField TextField_3;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					frame = new addchasis();
					frame.setTitle("Chasis");
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public addchasis() {
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(110, 95, 650, 400);
        setResizable(false);

        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setLayout(null);

        TextField = new JTextField();
        TextField.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField.setBounds(290, 125, 326, 40);
        contentPane.add(TextField);
        TextField.setColumns(10);

        TextField_1 = new JTextField();
        TextField_1.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField_1.setBounds(290, 175, 326, 40);
        contentPane.add(TextField_1);
        TextField_1.setColumns(10);
        
        TextField_2 = new JTextField();
        TextField_2.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField_2.setBounds(290, 225, 326, 40);
        contentPane.add(TextField_2);
        TextField_2.setColumns(10);
        
        TextField_3 = new JTextField();
        TextField_3.setFont(new Font("Tahoma", Font.PLAIN, 18));
        TextField_3.setBounds(290, 275, 326, 40);
        contentPane.add(TextField_3);
        TextField_3.setColumns(10);
        
        TextField.setText("");
		TextField_1.setText("");
		TextField_2.setText("");
		TextField_3.setText("");
		
		JLabel lbladdchasiss = new JLabel("Chasis");
        lbladdchasiss.setFont(new Font("Courier New", Font.BOLD, 36));
        lbladdchasiss.setForeground(Color.BLACK);
        lbladdchasiss.setBounds(275, 27, 200, 40);
        contentPane.add(lbladdchasiss);
        
		JLabel lblmanu = new JLabel("Manufacturer :");
        lblmanu.setFont(new Font("Big Calson", Font.PLAIN, 18));
        lblmanu.setBounds(45, 125, 326, 40);
        contentPane.add(lblmanu);
		
		JLabel lbllength = new JLabel("Length(cm) :");
        lbllength.setFont(new Font("Freestyle Script", Font.PLAIN, 18));
        lbllength.setBounds(45, 175, 410, 40);
        contentPane.add(lbllength);
        
		JLabel lblwidth = new JLabel("Width(cm) :");
        lblwidth.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblwidth.setBounds(45, 225, 470, 40);
        contentPane.add(lblwidth);
        
        JLabel lblweight = new JLabel("Weight(kg) :");
        lblweight.setFont(new Font("Tahoma", Font.PLAIN, 18));
        lblweight.setBounds(45, 275, 510, 40);
        contentPane.add(lblweight);
        
		JButton btnaddchasiss = new JButton("Submit");
		btnaddchasiss.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
			String m=TextField.getText();
			
			int l;
			int  w;
			int weight;
			
			if((TextField_1.getText()).equals(""))
				l = 0;
			else
				l=Integer.parseInt(TextField_1.getText());
			
			if((TextField_2.getText()).equals(""))
				w = 0;
			else
				w=Integer.parseInt(TextField_2.getText());
			
			if((TextField_3.getText()).equals(""))
				weight = 0;
			else
				weight=Integer.parseInt(TextField_3.getText());
			
			if(m.equals("") || l==0 || w==0 || weight==0 ) {
				JOptionPane.showMessageDialog(addchasis.this,"Unknown Error !!!\n TextField Cannot be Blank");
			}
			else {
			if(chasisdetails.checkchasis(m)) {
				JOptionPane.showMessageDialog(addchasis.this,"Details with Same Manufacture is present already\nInserton Failed !!!");
			}
			else {
			int i=chasisdetails.insertchasis(m,l,w,weight);
			if(i>0){
				JOptionPane.showMessageDialog(addchasis.this,"Details added successfully!");
			}else{
				JOptionPane.showMessageDialog(addchasis.this,"Unknown Error !!!\nInsertion not completed");
			}
			}
			}
			}
		});
		btnaddchasiss.setFont(new Font("Tahoma", Font.PLAIN, 20));
        btnaddchasiss.setBackground(new Color(0,0, 0));
        btnaddchasiss.setBounds(300, 315, 130, 50);
        contentPane.add(btnaddchasiss);

		
		JButton btnBack = new JButton("Back");
		btnBack.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e1) {
				chasis.main(new String[]{});
				frame.dispose();
			}
			});
		  btnBack.setFont(new Font("Tahoma", Font.PLAIN, 20));
	        btnBack.setBackground(new Color(240, 240, 240));
	        btnBack.setBounds(450, 315, 130, 50);
	        contentPane.add(btnBack);
	}

}
